export class ResultOk {
  data: any;
  constructor(data, msg: string) {
    this.data = data;
  }
}
