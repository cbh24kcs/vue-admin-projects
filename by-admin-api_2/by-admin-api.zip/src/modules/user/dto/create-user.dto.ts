export class CreateUserDto {
  name: string;
}
