export default class FormUrlEncodedParams {
  x: number;
  y: number;
}
