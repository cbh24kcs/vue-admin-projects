export class HnjmzyxyQueryDto {
  web_name: string;
  pageNum: number;
  pageSize: number;
}
