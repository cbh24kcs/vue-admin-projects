<template>
  <h1>HOME</h1>
</template>