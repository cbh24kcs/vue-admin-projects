// npm设置新淘宝源
npm config set registry https://registry.npmmirror.com

// npm设置回本源
npm config set registry https://registry.npmjs.org

